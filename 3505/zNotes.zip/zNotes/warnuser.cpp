#include "warnuser.h"
#include "ui_warnuser.h"

WarnUser::WarnUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::WarnUser)
{
    ui->setupUi(this);
}

WarnUser::~WarnUser()
{
    delete ui;
}
