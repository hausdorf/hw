#include <cstdio>

#include "spellcheckdialog.h"
#include "ui_spellcheckdialog.h"

SpellCheckDialog::SpellCheckDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SpellCheckDialog)
{
    ui->setupUi(this);
}

SpellCheckDialog::~SpellCheckDialog()
{
    delete ui;
}

void SpellCheckDialog::setParent(MainWindow *w)
{
    par = w;
}

void SpellCheckDialog::on_Next_clicked()
{
    par->NextMisspelling();
}
