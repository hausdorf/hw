#ifndef SPELLCHECKDIALOG_H
#define SPELLCHECKDIALOG_H

#include <QDialog>

#include "mainwindow.h"
#include "spellchecker/Dictionary.h"

namespace Ui {
    class SpellCheckDialog;
}

class SpellCheckDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SpellCheckDialog(QWidget *parent = 0);
    ~SpellCheckDialog();

    void setParent(MainWindow *w);

private:
    Ui::SpellCheckDialog *ui;
    MainWindow *par;

private slots:
    void on_Next_clicked();
};

#endif // SPELLCHECKDIALOG_H
