#ifndef WARNUSER_H
#define WARNUSER_H

#include <QDialog>

namespace Ui {
    class WarnUser;
}

class WarnUser : public QDialog
{
    Q_OBJECT

public:
    explicit WarnUser(QWidget *parent = 0);
    ~WarnUser();

private:
    Ui::WarnUser *ui;
};

#endif // WARNUSER_H
