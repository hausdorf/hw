/*
 * Hashtable.cpp
 *
 * CS 3505
 * Group: Godzillasaurus Rex
 * Authors: Alex Clemmer, Landon Gilbert-Bland, Colton Myers, Andrew Kuhnhausen
 * Version: 01/28/2011
 *
 * Description: This file has the Hashtable implementation
 */
#include <stdio.h>

#include "Hashtable.h"

using namespace std;

Hashtable::~Hashtable() {}

Hashtable::Hashtable()
{
    this->_base = new KeyVal[DEFAULT_BASE_SIZE]();
    this->_count = 0;
    this->_size = DEFAULT_BASE_SIZE;
    this->_verbose = false;
}

Hashtable::Hashtable(bool verbose)
{
    this->_base = new KeyVal[DEFAULT_BASE_SIZE]();
    this->_count = 0;
    this->_size = DEFAULT_BASE_SIZE;
    this->_verbose = verbose;
}

int Hashtable::add(string s)
{

    // Return 0, do not add if empty or null
    if(s == "")
        return 0;

    if(_verbose) printf("\tADD string \"%s\";\tcount before add: %d;\tsize: %d",
        s.c_str(), _count, _size);

    // Check to see if need to resize
    // SAFE: _size in Hashtable is unsigned to begin with
    if(_count >= this->_size/2)
    {
        rehash();
    }

    // Find the position
    int pos = find_pos(s);

    // look in base; if there, increment, if not, add and increment
    int curr_count;  // tracks the current "count" for our key
                     // we will return this value
    if(_base[pos].key() == "NOT GIVEN")
    {
        if(_verbose) printf("\tNEW KEY\n");

        _base[pos] = KeyVal(s, 1);
        curr_count = 1;

        // if we added a new element, increment tables total count
        _count++;
    }
    else
    {
        if(_verbose) printf("\tKEY EXISTS, val is: %d\n", _base[pos].val()+1);
        curr_count = _base[pos].inc_val();
    }

    return curr_count;
}

vector<string> Hashtable::keys()
{
    vector<string> keys;

    for(unsigned i = 0; i < _size; i++)
    {
        if(_base[i].key() != "NOT GIVEN")
        {
            keys.push_back(_base[i].key());
        }
    }

    return keys;
}

int Hashtable::operator[] (const string &s)
{
    return _base[find_pos(s)].val();
}

int Hashtable::count()
{
    return _count;
}

void Hashtable::rehash()
{
    if(_verbose) printf("\n\tinterrupt: REHASH\n");

    // Store base in temporary
    KeyVal* tmp = _base;

    // add counts when you add, so we need to reset _count
    _count = 0;

    // extend array _size to next largest prime; keep old _size around as
    // oldSize in order to aid with the copying of old vals into new table
    int oldSize = _size;
    _size = nextPrime(_size*2);

    // point base at new empty table
    _base = new KeyVal[_size];

    // re-hash all elements from old table into the new empty table
    for(int i = 0; i < oldSize; i++)
    {
        if(tmp[i].key() != "NOT GIVEN")
        {
            for(int n = 0; n < tmp[i].val(); n++)
            {
                if(_verbose)
                {
                    // Disable _verbose so add() doesn't print its normal
                    // statements; we only care about rehash()'s statements
                    _verbose = false;
                    printf("\t\tkey: %s; %d of %d;\n", tmp[i].key().c_str(), n,
                            tmp[i].val());
                    add(tmp[i].key());
                    _verbose = true;
                }
                else
                {
                    add(tmp[i].key());
                }
            }
        }
    }
    if(_verbose) printf("\t\tcontinuing last add(): ");

    delete [] tmp;
}

unsigned long Hashtable::hashcode(string s)
{
   unsigned long code = 0; // could be 5381
   const int shift = 5; // could be 6
   int len = (int) s.length();
   for (int i = 0; i < len; i++)
   {
       // keep the hash within the bounds of the array
       code = (((code << shift) + code) + code + s.at(i)) % this->_size;
   }

   return code;
}

int Hashtable::find_pos(string s)
{
    // Find hashcode for string
    unsigned long code = hashcode(s);

    // Quad probe for "true" position for string key
    int offset = 0;
    for( ; ; offset++)
    {
        KeyVal tmpElement = _base[(code+(offset*offset)) % this->_size];

        // if current element is our string key s
        if(tmpElement.key() == s)
            break;
        // if element is empty
        else if(tmpElement.key() == "NOT GIVEN")
            break;
    }

    // % has a higher binding power than +, so those parentheses are needed
    return (int) (code+(offset*offset)) % this->_size;
}

int Hashtable::size()
{
    return _size;
}

string Hashtable::KeyVal::key()
{
    return _key;
}

int Hashtable::KeyVal::val()
{
    return _val;
}

int Hashtable::KeyVal::inc_val()
{
    return ++_val;
}

int Hashtable::nextPrime(int n)
{
    if((n % 2) == 0)
        n++;
    else
        n += 2;

    for( ; !isPrime(n); n+=2)
        ;

    return n;
}

bool Hashtable::isPrime(int n)
{
    if(n == 2 || n == 3)
        return true;

    if(n == 1 || (n % 2) == 0)
        return false;

    for(int i = 3; i * i <= n; i += 2)
    {
        if(n % i == 0)
            return false;
    }

    return true;
}
