/*
 * File.h
 *
 * CS 3505
 * Group: GodzillasaurusRex
 * Authors: Alex Clemmer, Landon Gilbert-Bland, Colton Myers, Andrew Kuhnhausen
 * Version: 01/28/2011
 *
 * Description:  Header data for the File class.
 */

#ifndef __FILE_H
#define __FILE_H

#include <string>

#include "Hashtable.h"

/**
 * @brief File header file.
 * This is the header file for the File class. It contains all of the
 * public and private methods (documented) relating to a file parsing.
 *
 * This class provides a static methods used for parsing and pulling words out
 * of a file.
 *
 * Thid class contains only static methods, and it's constructor is private so
 * that it cannot be instanciated.
 */
class File
{

public:

    /**
     * @brief Parses the words from a file into a hash table.
     * Attempts to open a file with the given filename, and parse all of the
     * words in that file into a hashtable.
     *
     * The parsing will exclude ANYTHING that isn't a-z, including puncuation,
     * numbers, etc.
     *
     * Every string will be converted to lower case before it is added to the
     * hashtable.
     *
     * If there is a problem with anything, from reading to a file to adding
     * stfuff to the hashtable, then this method will return false. If
     * everything completed successfully true is returned.
     *
     * @param filename The filename of the file to parse
     * @param hashtable A pointer to an already constructed hashtable object
     *
     * @return True if the file could be successfully parsed and stored in the
     * hashtable, false otherwise.
     */
    static bool parse_file(std::string filename, Hashtable *hashtable);

    static void parse_string(std::string content, Hashtable *hashtable);

private:

    // Default Constructor. Private so this class cannot be instanciated
    File() {}
};

#endif
