/*
 * Dictionary.h
 *
 * CS 3505
 * Team: Godzillasaurus Rex
 * Authors: Colton Myers, Andrew Kuhnhausen, Landon Gilbert-Bland, Alex Clemmer
 * Version: 01/29/2011
 *
 * Description:  Contains the header information for the Dictionary class
 */
#ifndef DICTIONARY_H_
#define DICTIONARY_H_

#include <string>
#include <vector>
#include "Hashtable.h"
#include "Word_Count.h"
#include "File.h"

/**
 * @brief Main execution class for the SpellChecker library
 *
 * Main execution class for the SpellChecker library, handles integration and
 * communication between all the various pieces of the program.  Contains the
 * main algorithm for the actual spell-checking process, and handles the
 * interface with the file parsing and the writing of the spellchecking output.
 *
 * When a Dictionary is created, it will parse the file at the given filename,
 * and output a summary of all the mispelled words and the top 5 suggestions.
 * The Dictionary will then delete the hashtable representing the parsed file,
 * as the public API gives no access to it after the constructor ends anyway.
 * However, the Dictionary object will still be available to spell-check
 * individual words using the two other public methods.  If the default
 * constructor (with no arguments) is called, the Dictionary object will be
 * created without spell-checking a specific file, and will be available for
 * individual spell-checks as normal.
 */
class Dictionary
{

public:

    // PUBLIC METHODS //////////////////////////////////////////////////////////

    /**
     * @brief Constructor
     */
    Dictionary();

    /**
     * @brief Constructor for spellchecking a file
     *
     * Creates a dictionary object and spellchecks the given file using
     * the check_file() method.
     *
     * @param file_name The filename of the file to be spellchecked
     */
    Dictionary(std::string file_name);

    /**
     * @brief Deconstructor
     */
    ~Dictionary();

    /**
     * @brief Method to spellcheck a file
     *
     * Spellchecks the file respresented by the given filename, and outputs
     * the results to the standard output.
     *
     * @param file_name The filename of the file to be spellchecked
     */
    void check_file(std::string file_name);

    std::vector<std::string>* check_string(std::string content);

    /**
     * @brief Checks if a word is spelled correctly
     *
     * Takes a given word and checks if it is spelled correctly. If it is
     * spelled correctly then true is returned, otherwise false is returned.
     *
     * @param word The word to check if is spelled correctly
     *
     * @return True if the word is spelled correctly, false otherwise
     */
    bool spelled_correctly(std::string word);

    /**
     * @brief Finds the best matchs for a word if it is spelled incorrectly
     *
     * Checks if the given word is spelled correctly. If it is then true is
     * returned. If it isn't then false is returned and the alternate
     * spellings for the word are stored in the list reference.
     *
     * If the word is spelled incorrectly, 5 alternate best matches for the
     * word will be stored into the list reference. This quantity can be
     * overriden by the caller.
     *
     * @param word The word to check
     *
     * @param list A reference of a vector of strings that will hold the
     *             alternate spellings for this word, if it is spelled
     *             incorrectly.
     *
     * @param count The number of alternate words to find if this word is
     *              spelled incorrectly
     *
     * @return True if word is spelled correctly, false otherwise. If
     *         word isn't spelled correctly then the 5 best alternate spellings
     *         will be stored in list.
     */
    bool best_matches(std::string word,
            std::vector<std::string> &list,
            int count=5);

    // PUBLIC MEMBERS //////////////////////////////////////////////////////////

private:

    // PRIVATE METHODS /////////////////////////////////////////////////////////

    /**
     * @brief Finds the valid alternate spellings/counts for given word
     *
     * Given a word, find the valid alternate spellings (as well as the counts
     * for those spellings based on the histogram) for that word.
     *
     * @param word The word for which valid alternate spellings are to be found
     *
     * @param words The vector to which the valid alternate words should be
     *              written
     *
     * @param counts The counts for the respective valid alternate words stored
     *               in &words
     */
    void valid_spellings(std::string word,
                         std::vector<std::string> &words,
                         std::vector<int> &counts);

    /**
     * @brief Sorts the words and counts vectors by count using insertion sort
     *
     * The two vectors, &words and &counts, are used in parallel to sort the
     * words by their counts in descending order, using insertion sort
     *
     * @param words A reference to the vector containing the words to be sorted
     *
     * @param counts A reference to the counts by which the words will be sorted
     */
    void insertion_sort(std::vector<std::string> &words,
                        std::vector<int> &counts);

    // PRIVATE MEMBERS /////////////////////////////////////////////////////////

    /**
     * @brief Hashtable representing the parsed file to be spellchecked
     *
     * Hashtable (though used like a Hashset) of all the words in the file
     * to be spellchecked.  Only instantiated during the spellchecking process,
     * then immediately deleted.  The reason it is a member variable is for
     * future expandability (allows us to keep it in memory to use it for other
     * purposes if required in the future)
     */
    Hashtable *parsed_file;

    /**
     * @brief Hashtable representing the histogram/dictionary for spellcheck
     *
     * Hashtable representation of our corpus. Used to check if words are
     * mispelled, as well as to see which words are most commonly used for
     * use in best_matches.
     */
    Hashtable *histogram;


    /**
     * @brief Transposes the letters of the given string.
     * Transposes the letters of the given string to try and find
     * words that are spelled correctly
     *
     * @param words The vector that contains valid words
     * @param counts The vector that contains the word counts
     * @param word The word that we are transposing the letters of
     */
    void transpose_letters(std::vector<std::string> &words,
                           std::vector<int> &counts,
                           std::string word);

    /**
     * @brief Replaces chars in a string to find valid words
     * Replaces every letter in a string with every other letter in a
     * string to try to find words that are spelled correctly
     *
     * @param words The vector that contains valid words
     * @param counts The vector that contains the word counts
     * @param word The word that we are transposing the letters of
     */
    void replace_letters(std::vector<std::string> &words,
                         std::vector<int> &counts,
                         std::string word);
    /**
     * @brief Inserts chars in a string to find valid words
     * Inserts every letter in every position on a string to try and find
     * words that are spelled correctly
     *
     * @param words The vector that contains valid words
     * @param counts The vector that contains the word counts
     * @param word The word that we are transposing the letters of
     */
    void insert_letters(std::vector<std::string> &words,
                        std::vector<int> &counts,
                        std::string word);

    /**
     * @brief Removes chars in a string to find valid words
     * Removes every letter in this string to try and find
     * words that are spelled correctly
     *
     * @param words The vector that contains valid words
     * @param counts The vector that contains the word counts
     * @param word The word that we are transposing the letters of
     */
    void remove_letters(std::vector<std::string> &words,
                        std::vector<int> &counts,
                        std::string word);

    /**
     * @brief Inserts chars in a string to find valid words
     * Inserts letters at the end of the string to try and create a valid
     * word
     *
     * @param words The vector that contains valid words
     * @param counts The vector that contains the word counts
     * @param word The word that we are transposing the letters of
     */
    void insert_letters_end(std::vector<std::string> &words,
                            std::vector<int> &counts,
                            std::string word);
};

#endif
