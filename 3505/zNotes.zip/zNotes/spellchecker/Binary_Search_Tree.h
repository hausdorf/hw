/*
 * Binary_Search_Tree.h
 *
 * CS 3505
 * Group: Godzillasaurus Rex
 * Authors: Alex Clemmer, Landon Gilbert-Bland, Colton Myers, Andrew Kuhnhausen
 * Version: 01/28/2011
 *
 * Description:  Header data for the Binary Search Tree object.
 */
#ifndef __BINARYSEARCHTREE_H
#define __BINARYSERACHTREE_H

#include <string>

/**
 * @brief Binary_Search_Tree header file.
 * This is the header file for the binary search tree. It contains all of the
 * public and private methods (documented) relating to a bst.
 *
 * It is important to know that this is NOT a self balancing binary search tree.
 * Thus if you are going to add a bunch of string to this tree, you should
 * randomize the order in which you input them into the tree. Failure to do
 * this can prevent the binary search tree from having nlong(n) behiavor for
 * lookups, and at worst case would have linear lookup time.
 */
class Binary_Search_Tree
{
public:
    /**
     * @brief Constructor
     * Creates a new empty Binary_Search_Tree object.
     */
    Binary_Search_Tree();


    /**
     * @brief Destructor
     * Deletes this binary search tree.
     */
    ~Binary_Search_Tree();

    /**
     * @brief Adds a string into the binary search tree
     * This will add a string into the binary search tree. If the string doesn't
     * currently exist in the tree then it will be added to the tree and true
     * will be returned. If the string is already in the tree then false is
     * returned.
     *
     * NOTE: This is *not* a balancing binary search tree. Thus unless you are
     * looking for a linked list, you must randomize the string before you add
     * them to the tree so that it will retain something resabmling nlong(n)
     * behaivor.
     *
     * @param s The string to add to the binary search tree
     *
     * @return True if the sting didn't already exist in the tree and was added
     * by this method, false otherwise
     */
    bool add(std::string s);

    /**
     * @brief Checks if a string exists in the binary search tree
     * This will check if a given string exists in the binary search tree. If
     * the string exists in the tree then true is returned, otherwise false
     * is returned.
     *
     * @param s The string to check if exists in the tree.
     *
     * @return True if the string exists in the tree, false otherwise
     */
    bool contains(std::string s);

private:
    class Node
    {
    public:
        /**
         * @brief Constructor
         * Creates a new node object. The node object takes a string, and
         * stores a copy of it on the heap.
         *
         * When a new node is created, each of its children nodes are NULL
         *
         * @param s A pointer to the node this string will contain
         */
        Node(std::string s);

        /**
         * @brief Destructor
         * When a node is destroyed, it will call the destructor on all of
         * its children nodes, then delete the string stored in this node.
         */
        ~Node();

        // Contains the string value held in this node
        std::string *value;

        // Contains the left child node of this node
        Node *lChild;

        // Contains the right child node of thi node
        Node *rChild;

    private:
        // Private default constructor, so Node objects can only be instanciated
        // with a string
        Node();
    };

    // The root node of the binary search tree;
    Node *_root;

    /**
     * @brief Finds where a given string should be added into the tree
     * Recursivly searches through the binary search tree to find the location
     * that it should be added.
     *
     * If this string is not already in the tree then it is added to the tree
     * and true is returned. If the string is already in the tree then no
     * change is made to the tree and false is returned.
     *
     * @param value A pointer to a string that is being added to the tree
     * @param node A pointer to the current node that is being checked
     *
     * @return True if this item didn't exist in the tree and was added to the
     * tree, false otherwise.
     */
    bool add(std::string& value, Node *node);

    /**
     * @brief Recursively checks if a given string exists in the tree
     * Recursivly searches through the binary search tree to check if this
     * string exists in the tree. If the string is found in the tree, true
     * is returned. Otherwise false is returned.
     *
     * @param value The string value to check if exists in the tree
     * @param node A pointer to the current node that is being checked
     *
     * @return True if the string exists in this tree, false otherwise
     */
    bool contains(std::string& value, Node *node);
};

#endif
