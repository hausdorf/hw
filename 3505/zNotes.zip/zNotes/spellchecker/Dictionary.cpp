/**
 * Dictionary.cpp
 *
 * CS 3505
 * Team: Godzillasaurus Rex
 * Authors: Colton Myers, Andrew Kuhnhausen, Landon Gilbert-Bland, Alex Clemmer
 * Version: 01/29/2011
 *
 * Description:  Contains the implementation code for the Dictionary class
 */
#include <iostream>
#include "Dictionary.h"
#define DEBUG // COMMENT THIS WHEN NOT DEBUGGING!

Dictionary::Dictionary()
{
    // Initialize our histogram
    histogram = new Hashtable();

    // It is possible the corpus wont be loaded here (IO error). If so we
    // should probably handle that somehow (same thing on line 29)
    File::parse_file("spellchecker/corpus", histogram);

    return;
}

Dictionary::Dictionary(std::string file_name)
{
    // Initialize our histogram
    histogram = new Hashtable();

    // if we are debugging, the filename is a testing corpus
    #ifdef DEBUG
        histogram = new Hashtable();
        File::parse_file(file_name, histogram);
        return;
    #endif

    File::parse_file("spellchecker/corpus", histogram);

    // Spellcheck the given file
    check_file(file_name);

    return;
}

Dictionary::~Dictionary()
{
    delete histogram;
}

void Dictionary::check_file(std::string file_name)
{
    // Create hashtable to store the file
    Hashtable *file = new Hashtable();

    // Parse the file
    if(!File::parse_file(file_name, file))
    {
        // Output error
        std::cout << "\nERROR:  File " << file_name << " did not parse correctly.\n";
        return;
    }

    // Get the list of words to be spellchecked
    std::vector<std::string> words = file->keys();

    // Announce check_file
	std::cout << "SPELL_CHECK for file: " << file_name << "\n\n";

    // Iterate over all the words, printing the misspelled word and their
    // alternate spellings to the stdout
    for(int i = 0; i < (int)(words.size()); i++)
    {
        if(!spelled_correctly(words.at(i)))
        {
            // Print the misspelled word
            std::cout << words.at(i) << " is spelled incorrectly.  Best matches:\n";

            // Create list to hold the best matches
            std::vector<std::string> list;

            // Populate the best matches
            best_matches(words.at(i), list);

            // Print the best matches, tab-separated
            for(int j = 0; j < (int)(list.size()); j++)
            {
                std::cout << "\t" << list.at(j);
            }

            // Print newline before next spellcheck
            std::cout << std::endl;
        }
    }
}

std::vector<std::string>* Dictionary::check_string(std::string content)
{
    // Create hashtable to store the file
    Hashtable *file = new Hashtable();

    // Parse the string
    File::parse_string(content, file);

    // Get the list of words to be spellchecked
    std::vector<std::string> words = file->keys();

    std::vector<std::string> *misspelled = new std::vector<std::string>();

    // Announce check_file
    //std::cout << "SPELL_CHECK for file: " << content << "\n\n";

    // Iterate over all the words, printing the misspelled word and their
    // alternate spellings to the stdout
    for(int i = 0; i < (int)(words.size()); i++)
    {
	if(!spelled_correctly(words.at(i)))
	{
	    misspelled->push_back(words.at(i));

	    // Print the misspelled word
	    //std::cout << words.at(i) << " is spelled incorrectly.  Best matches:\n";

	    // Create list to hold the best matches
	    //std::vector<std::string> list;

	    // Populate the best matches
	    //best_matches(words.at(i), list);

	    // Print the best matches, tab-separated
	    /*for(int j = 0; j < (int)(list.size()); j++)
	    {
		std::cout << "\t" << list.at(j);
	    }*/

	    // Print newline before next spellcheck
	    //std::cout << std::endl;
	}
    }
    return misspelled;
}

bool Dictionary::spelled_correctly(std::string word)
{
    // Convert string to lower using a char* and std::tolower()
    for(unsigned i = 0; i < word.size(); i++)
    {
        word.at(i) = tolower(word.at(i));
    }

    // Return whether the word is in our histogram
    if ((*histogram)[word] > 0)
    {
        return true;
    }
    return false;
}

bool Dictionary::best_matches(std::string word,
                              std::vector<std::string> &list,
                              int count)
{
    // Check spelling
    if(spelled_correctly(word))
        return true;

    // Create vectors to keep track of valid alternate spellings
    std::vector<int> counts;
    std::vector<std::string> words;

    // Get valid alternate spellings
    valid_spellings(word, words, counts);

    // Sort the results by histogram count (for _best_ matches)
    insertion_sort(words, counts);

    // Put the requested number of best matches in the given list reference
    for(int i = 0; i < count && i < (int)(words.size()); i++)
    {
        list.push_back(words.at(i));
    }

    // Return false, as the originally given word was misspelled
    return false;
}

void Dictionary::valid_spellings(std::string word,
                                 std::vector<std::string> &words,
                                 std::vector<int> &counts)
{

    // make word all lowercase
    for(unsigned i=0; i<word.size(); i++)
    {
        word.at(i) = tolower(word.at(i));
    }

    // Holds variations of this word we create
    std::string new_word = word;

    // Tracks if a word is in the histogram
    int word_count=0;

    /**
     * Main for loop that runs Insert, Replace, Transpose
     */
    for(unsigned i=0; i<word.size(); i++)
    {
        /** Transpose neighboring letters **/
        if (i < new_word.size() - 1)
        {
            new_word = word;

            // grab first neighboring letter
            int current = new_word.at(i);

            // switch them
            new_word.at(i) = new_word.at(i + 1);
            new_word.at(i + 1) = current;

            // check if the word exists in the dictionary
            word_count = (*histogram)[new_word];

            // if so, add the value and key to respective arrays
            if(word_count > 0)
            {
                words.push_back(new_word);
                counts.push_back(word_count);
            }
        }

        /** Replace current letter **/
        // Replace this character with every other character in the alphabet,
        // and check if that makes a valid word
        new_word = word;

        for(int new_char='a'; new_char<='z'; new_char++)
        {
            // replace the current char with a new character
            new_word.at(i) = new_char;

            // check if it creates a new valid word
            word_count = (*histogram)[new_word];
            if(word_count > 0)
            {
                words.push_back(new_word);
                counts.push_back(word_count);
            }
        }

        /** Insert 1 and 2 extra characters **/
        // Check if the word is misspelled due to a missing letter by inserting
        // every letter in the alphabet behind this current character, and
        // checking if that creates a valid word
        new_word = word;
        new_word.insert(new_word.begin() + i, 'a');
        for(int new_char='a'; new_char<='z'; new_char++)
        {
            new_word.at(i) = new_char;

            // insert an extra character
            std::string new_word2 = new_word;
            new_word2.insert(new_word2.begin() + i, 'a');
            for (int new_char2='b'; new_char2<='z'; new_char2++)
            {
                new_word2.at(i) = new_char2;
                word_count = (*histogram)[new_word2];
                if (word_count > 0)
                {
                    bool wordAlreadyExists = false;
                    for(unsigned i=0; i<words.size(); i++)
                    {
                        if(words.at(i) == new_word2)
                        {
                            wordAlreadyExists = true;
                            break;
                        }
                    }

                    if(!wordAlreadyExists)
                    {
                        words.push_back(new_word2);
                        counts.push_back(word_count);
                    }

                }
            }

            // continue with just one character
            word_count = (*histogram)[new_word];
            if(word_count > 0)
            {
                // It is possible that the word has already been added, for
                // example bok could add book twice (bOok vs boOk). Therefore
                // insure the word we are adding doesn't already
                bool wordAlreadyExists = false;
                for(unsigned i=0; i<words.size(); i++)
                {
                    if(words.at(i) == new_word)
                    {
                        wordAlreadyExists = true;
                        break;
                    }
                }

                if(!wordAlreadyExists)
                {
                    words.push_back(new_word);
                    counts.push_back(word_count);
                }
            }
        }

        /** Remove current character **/
        // Check if the word is spelled incorrecty due to an extra letter in
        // the word by removing this character and checking if the word is
        // valid
        new_word = word;
        new_word.erase(new_word.begin() + i);

        word_count = (*histogram)[new_word];
        if(word_count > 0)
        {
                // It is possible that the word has already been added, for
                // example bok could add book twice (bOok vs boOk). Therefore
                // insure the word we are adding doesn't already
                bool wordAlreadyExists = false;
                for(unsigned i=0; i<words.size(); i++)
                {
                    if(words.at(i) == new_word)
                    {
                        wordAlreadyExists = true;
                        break;
                    }
                }

                if(!wordAlreadyExists)
                {
                    words.push_back(new_word);
                    counts.push_back(word_count);
                }
            //words.push_back(new_word);
            //counts.push_back(word_count);
        }
    }

    /** Insert 1 and 2 letters at end of word **/
    // We still need to check if the word is valid by inserting each letter
    // in the alphabet at the very end of the word.
    new_word = word;
    new_word.push_back('a');
    for(int new_char='a'; new_char<='z'; new_char++)
    {
        // grab the last element
        new_word.at(new_word.size() - 1) = new_char;

        // insert a second extra character
        std::string new_word2 = new_word;
        new_word2.push_back('a');
        for (int new_char2='b'; new_char2<='z'; new_char2++)
        {
            new_word2.at(new_word2.size() - 1) = new_char2;
            word_count = (*histogram)[new_word2];
            if (word_count > 0)
            {
                bool wordAlreadyExists = false;
                for(unsigned i=0; i<words.size(); i++)
                {
                    if(words.at(i) == new_word2)
                    {
                        wordAlreadyExists = true;
                        break;
                    }
                }

                if(!wordAlreadyExists)
                {
                    words.push_back(new_word2);
                    counts.push_back(word_count);
                }

            }
        }

        // look at just one character
        word_count = (*histogram)[new_word];
        if(word_count > 0)
        {
            bool wordAlreadyExists = false;
            for(unsigned i=0; i<words.size(); i++)
            {
                if(words.at(i) == new_word)
                {
                    wordAlreadyExists = true;
                    break;
                }
            }

            if(!wordAlreadyExists)
            {
                words.push_back(new_word);
                counts.push_back(word_count);
            }
        }
    }

}

void Dictionary::insertion_sort(std::vector<std::string> &words,
                                std::vector<int> &counts)
{
    int len = (int) counts.size(); // grab the total size
    int i, j; // loop counters
    std::string word; // temporary string
    int count; // temporary count

    // basic insertion sort in descending order
    for (i = 1; i < len; i++)
    {
        j = i;
        // compare the counts and sort in descending order
        while (j > 0 && counts.at(j - 1) < counts.at(j))
        {
            // grab the word and count from their vectors
            word = words.at(j);
            count = counts.at(j);

            // swap the words
            words.at(j) = words.at(j - 1);
            words.at(j - 1) = word;

            // swap the counts
            counts.at(j) = counts.at(j - 1);
            counts.at(j - 1) = count;

            j--;
        }
    }
}
