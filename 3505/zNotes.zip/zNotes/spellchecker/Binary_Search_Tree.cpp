/*
 * Binary_Search_Tree.cpp
 *
 * CS 3505
 * Group: Godzillasaurus Rex
 * Authors: Alex Clemmer, Landon Gilbert-Bland, Colton Myers, Andrew Kuhnhausen
 * Version: 01/28/2011
 *
 * Description: Implementation of the Binary_Search_Tree.h header file
 */
#include "Binary_Search_Tree.h"

Binary_Search_Tree::Binary_Search_Tree()
{
    _root = NULL;
}

Binary_Search_Tree::~Binary_Search_Tree()
{
    // This will recursivly delete every node in the bst
    delete _root;
}

bool Binary_Search_Tree::add(std::string s)
{
    // If the string is empty, then ignore it
    if(s.empty())
    {
        return false;
    }

    // If the bst is currently empty, then set this string as the root.
    if(_root == NULL)
    {
        _root = new Node(s);
        return true;
    }

    // Find and add this string to the bst if it isn't already in the tree
    return add(s, _root);
}

bool Binary_Search_Tree::contains(std::string s)
{
    if(_root == NULL)
    {
        return false;
    }

    if(s.empty())
    {
        return false;
    }

    return contains(s, _root);
}

bool Binary_Search_Tree::add(std::string& value, Node* node)
{
    std::string *nodeString = node->value;
    if(value.compare(*nodeString) == 0)
    {
        return false;
    }
    else if(value.compare(*nodeString) < 0)
    {
        if(node->lChild == NULL)
        {
            Node *n = new Node(value);
            node->lChild = n;
            return true;
        }
        else
        {
            return add(value, node->lChild);
        }
    }
    else /* if(value.compare(*nodeString) > 0) */
    {
        if(node->rChild == NULL)
        {
            Node *n = new Node(value);
            node->rChild = n;
            return true;
        }
        else
        {
            return add(value, node->rChild);
        }
    }
}

bool Binary_Search_Tree::contains(std::string& value, Node* node)
{
    std::string *nodeString = node->value;

    if(value.compare(*nodeString) == 0)
    {
        return true;
    }
    else if(value.compare(*nodeString) < 0)
    {
        if(node->lChild == NULL)
        {
            return false;
        }
        else
        {
            return contains(value, node->lChild);
        }
    }
    else /* if(value.compare(*nodeString) > 0) */
    {
        if(node->rChild == NULL)
        {
            return false;
        }
        else
        {
            return contains(value, node->rChild);
        }
    }
}

Binary_Search_Tree::Node::Node(std::string s)
{
    std::string *sCopy = new std::string(s);
    this->value = sCopy;
    this->lChild = NULL;
    this->rChild = NULL;
}

Binary_Search_Tree::Node::~Node()
{
    delete lChild;
    delete rChild;
    delete value;
}
