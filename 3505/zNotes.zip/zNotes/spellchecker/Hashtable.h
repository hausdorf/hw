/*
 * Hashtable.h
 *
 * CS 3505
 * Group: Godzillasaurus Rex
 * Authors: Alex Clemmer, Landon Gilbert-Bland, Colton Myers, Andrew Kuhnhausen
 * Version: 01/28/2011
 *
 * Description: This file has the Hashtable implementation details
 */
#ifndef __HASHTABLE_H
#define __HASHTABLE_H

#include <string>
#include <vector>

/**
 * @brief Holds strings as keys and int as vals; used to count word frequency
 * Important to note is that there is no remove function. The table is
 * implemented via probing. Rehashing is done by creating a new table with a
 * size of the next prime after 2* the current size. Hashtable contains nodes
 * of internal type KeyVal, which holds a string as a key and a int as the val.
 * Users can access elements by the overloaded [] operators, which returns
 * the total count for that word.
 */
class Hashtable
{
public:
    /**
     * @brief Constructor
     * Uses the default size of 101 for the vector that holds all the
     * KeyVal objects
     */
    Hashtable();

    /**
     * @brief Constructor
     * Uses the default size of 101 for the vector that holds all the
     * KeyVal objects
     *
     * @param bool verbose Print out debugging info to stdout
     */
    Hashtable(bool verbose);

    /**
     * @brief Deconstructor
     * Empty
     */
    ~Hashtable();

    /**
     * @brief Adds a string to this dictionary
     * Adds a string to this dictionary if it isn't already there, or if
     * it is already there increments the count for the number of times this
     * word has showed up. Also increments the total number of words that
     * are stored in this dictionary.
     *
     * @param s The string to add
     *
     * @return The number of items this word has appeared in the has table 
     */
    int add(std::string s);

    /**
     * @brief Returns set of all keys in dictionary
     * Traverses the hash table and simply returns every key.
     *
     * @param keys Reference to an array you want populated with the keys
     *
     * @param vals Reference to an array you want populated with the vals
     */
    void contents(std::string **keys, int **vals);

    /**
     * @brief Returns all keys in dictionary
     *
     * @return Vector of all keys in table
     */
    std::vector<std::string> keys();

    /**
     * @brief [] returns the number of times a string exists in the dictionary
     * This overloads the [] operator to return the number of times the given
     * string appears in this dictionary. If the string does not appear in
     * this dictionary then zero is returned.
     *
     * @param s The string to check in the dictionary
     *
     * @return The number of times a string appears in this dictionary
     */
    int operator[] (const std::string &s);

    /**
     * @brief Returns count of occupied elements inside the hashtable
     * Does NOT return the number of elements in the array, but rather, the
     * number of *occupied* elements in the array. This is just a simple count
     * that we keep track of.
     */
    int count();

    /**
     * @brief Returns total capacity of current Hashtable object
     * This exists mainly because C++ does not have a size() operator for
     * 2-D arrays.
     */
    int size();

private:
    /**
     * @brief Hash every entry into a new table
     * Loops through every key in the vector and puts it into the "new" hash
     * table. When all elements are added, we point the old hash at the new
     * one and destruct everything in the old one.
     */
    void rehash();

    /**
     * @brief Outputs a hashcode for some given string
     * This implementation is a hybrid between Weiss and DBJ2's hashcode
     * algorithm.
     *
     * @param s The string to get the hashcode for
     *
     * @return The hashcode for the given string
     */
    unsigned long hashcode(std::string s);

    /**
     * @brief Quadratically probes base to find the position for string
     * Essentially looks over the base underlying array of the Hashtable using
     * quadratic probing, and finds a place for the new element. Since we are
     * not implementing a remove() method, this is a lot simpler than it
     * could be.
     *
     * @param s The string to find the position for
     *
     * @return The position for the given string
     */
    int find_pos(std::string s);

    /**
     * @brief Finds a prime bigger than n
     * Algorithm taken directly from Weiss; not efficient.
     *
     * @param The number you want the prime to fall after
     *
     * @return The next prime
     */
    int nextPrime(int n);

    /**
     * @brief Tests if some number is prime
     * Algorithm taken directly from Weiss; not efficient.
     *
     * @param Number to test primality of
     *
     * @return Whether param n is prime or not
     */
    bool isPrime(int n);

    /**
     * Holds a word (the key) and word's count (the value)
     */
    class KeyVal
    {
    public:

        /**
         * Private constructor is disallowed
         */
        KeyVal() {
            _key = "NOT GIVEN";
            _val = -1;
        }

        ~KeyVal() { }

        /**
         * @brief Constructor
         * KeyVal holds a key-val combination for the hash table.
         *
         * @param key The string to use as key
         * @param val The int that represent the count of the key string
         */
        KeyVal(std::string key, int val)
        {
            this->_key = key;
            this->_val = val;
        }

        /**
         * @brief Gets the key value for current KeyVal object
         *
         * @return The key value
         */
        std::string key();

        /**
         * @brief Gets val value for current KeyVal object
         *
         * @return The val value
         */
        int val();

        /**
         * @brief Increments _val, which "counts" the key in a document
         * We simply increment _val, which is an int.
         *
         * @return _val's value after we increment it
         */
        int inc_val();

    private:

        /**
         * @brief Holds the key string for the current KeyVal object
         */
        std::string _key;

        /**
         * @brief Holds value paired with the key for current KeyVal object
         */
        int _val;
    };

    /**
     * @brief Base of Hashtable, holds all KeyVal objects
     */
    KeyVal *_base;

    /**
     * @brief The total capacity of the current Hashtable
     */
    unsigned _size;

    /**
     * @brief The number of elements in base that are currently occupied
     */
    unsigned _count;

    /**
     * @brief Forces program to print every step it takes.
     */
    bool _verbose;

    /**
     * @brief Default size for base array, used in Hashtable constructor
     */
    static const int DEFAULT_BASE_SIZE = 101;
};

#endif
