/*
 * Word_Count.h
 *
 * CS 3505
 * Group: Godzillasaurus Rex
 * Authors: Alex Clemmer, Landon Gilbert-Bland, Colton Myers, Andrew Kuhnhausen
 * Version: 01/28/2011
 *
 * Description: This file has the Word_Count implementation details
 */
#ifndef __WORD_COUNT_H
#define __WORD_COUNT_H

#include <string>
#include <vector>

/**
 * The Word_Count class implements a histogram.
 * Its main purpose is to allow our program to add words
 * and keep track of how often a particular word is seen. Also has the
 * capability to return the top X words and how aften those words occur.
 */
class Word_Count
{
public:

    // CONSTRUCTORS DESTRUCTORS =============================================
    /**
     * @brief Constructor
     */
    Word_Count();

    /**
     * @brief Destructor
     */
    ~Word_Count();

    // PUBLIC METHODS =======================================================
    /**
     * @brief Counts the word
     * Takes a string and increments the count
     *
     * @param word The word to count
     */
    void add_word( std::string word );

    /**
     * @brief Retrieve the global count of a word
     * Returns how often the word has been seen
     *
     * @param word The word you want to get the count of
     *
     * @return The number of times the word has been seen
     */
    int get_word_count( std::string word );

    /**
     * @brief Retrieve the most frequent words
     * Returns a list of the most commonly used words. The number of words is
     * determined by the count parameter. If you ask call with count 5, you
     * will get the top 5 words and how often those words are used
     *
     * @param word_list A reference to a list of words
     * @param counts A reference to the count of the words
     * @param count The number of words to return
     */
    void get_top_words( std::vector<std::string> &word_list,
                        std::vector<int> &counts,
                        int count );

private:
    /**
     * @brief The Node class represents a pair: 1 word and its count.
     * Both word and count are public to the class, because they will only be
     * accessed by the Word_Count class, and that saves a function call.
     */
    class Node
    {
    public:

        // CONSTRUCTORS DESTRUCTORS ==========================================
        /**
         * Constructor
         * Default constructor that assigns this node a word and count = 1
         *
         * @param word The word for this Node
         */
        Node(std::string word);

        /**
         * Deconstructor
         * Empty
         */
        ~Node();

        // PUBLIC METHODS ====================================================


        // PUBLIC MEMBERS ====================================================

        /**
         * The word this node holds
         */
        std::string word;

        /**
         * The current count of this node
         */
        int count;

    private:
        // PRIVATE METHODS ===================================================

        // PRIVATE MEMBERS ===================================================
    };

    // PRIVATE METHODS =======================================================
    /**
     * Inserts Node in Descending order
     * Compares Node to the left, if that Node has a higher count this Node
     * gets place after, other wise it looks at the next Node the left.
     * In the case that two nodes are equal, this Node will be placed in
     * the position to the right of the other Node
     *
     * @param word The Node to move
     * @param position The position in the vector where the Node is
     */
    void move(Node node, int position);

    // PRIVATE MEMBERS =======================================================
    /**
     * Vector of Nodes
     */
    std::vector<Node> _words;
};
#endif
