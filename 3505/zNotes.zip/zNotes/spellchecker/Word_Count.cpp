/*
 * Word_Count.cpp
 *
 * CS 3505
 * Group: Godzillasaurus Rex
 * Authors: Alex Clemmer, Landon Gilbert-Bland, Colton Myers, Andrew Kuhnhausen
 * Version: 01/28/2011
 *
 * Description: Implements the Word_Count class
 */
#include "Word_Count.h"
#include <vector>
#include <string>

Word_Count::Word_Count()
{
    std::vector<Node> _words;
}

Word_Count::~Word_Count() {}

void Word_Count::add_word(std::string word)
{
    // if there are no words, add this and set its count
    if (_words.size() == 0)
    {
        Node node = Node(word);
        _words.push_back(node);
        return;
    }

    bool found = false; // true if word is found
    // look through the list of Nodes
    for (int i = 0; i < (int) _words.size(); i++)
    {
        std::string cur_word = _words.at(i).word;

        // if the string doesn't match move on
        if (cur_word.compare(word) != 0)
            continue;

        // increment the count and move this word to its proper location
        _words.at(i).count++;

        // move the current Node up the list
        if (i != 0)
        {
            // copy the Node, pass that copy
            Node current = _words.at(i);
            move(current, i);
        }

        found = true;

        // if we've gotten here, we're done
        break;
    }

    // the word is new, add it to the end of the list
    if (!found)
    {
        Node node = Node(word);
        _words.push_back(node);
    }
}

int Word_Count::get_word_count(std::string word)
{
    // look at each word until we find it, return the count
    for (int i = 0; i < (int) _words.size(); i++)
    {
        Node node = _words.at(i);

        // if the word doesn't match, move on
        if (node.word.compare(word) != 0)
            continue;

        return node.count;
    }

    // if we reach here, then the word doesn't exist
    return 0;
}

void Word_Count::get_top_words(std::vector<std::string> &word_list,
                               std::vector<int> &counts,
                               int count=50)
{

    // add the word and count from each Node until we reach 'count' size
    for (int i = 0; i < count && i < (int) _words.size(); i++)
    {
        Word_Count::Node node = _words.at(i);

        word_list.push_back(node.word);
        counts.push_back(node.count);
    }

}

// PRIVATE =================================================================
void Word_Count::move(Node node, int position)
{
    // don't move it if the count to the left is already higher
    if (_words.at(position - 1).count >= node.count)
        return;

    // if words is only 2 words, swap them
    if ((position - 2) < 0)
    {
        // insert this to the head, and move the head to tail
        std::vector<Node>::iterator iter;
        iter = _words.begin();
        // remove the Node from its previous position
        _words.erase(iter+position);
        // insert the copy of the node into the new position
        _words.insert(iter, node);
    }

    // look at each Node to the left, insert this node to the Right of the
    // first Node that has a count higher than this node
    for (int i = position - 2; i >= 0; i--)
    {
        Node left = _words.at(i);

        // move left, if this node's count is higher
        if (left.count < node.count)
            continue;


        // if this node's count is equal or greater than the node to its left
        // insert this node to the right of it.
        std::vector<Node>::iterator iter;
        iter = _words.begin();
        // remove the Node from its previous position
        _words.erase(iter+position);
        // insert the copy of the node into the new position
        _words.insert(iter + (i+1), node);


        // if we've ended up here, we are done
        break;
    }
}

/** Node class definitions **/
Word_Count::Node::Node(std::string word)
{
    this->word = word;
    this->count = 1;
}

Word_Count::Node::~Node(){}
