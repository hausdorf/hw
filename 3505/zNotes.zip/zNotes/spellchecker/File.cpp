/*
 * File.cpp
 *
 * CS 3505
 * Group: GodzillasaurusRex
 * Authors: Alex Clemmer, Landon Gilbert-Bland, Colton Myers, Andrew Kuhnhausen
 * Version: 01/28/2011
 *
 * Description: Implementation of the File.h header file
 */

#include "File.h"
#include <iostream>
#include <fstream>  // Read data from a file.
#include <locale>   // Provides tolower and isalpha

bool File::parse_file(std::string filename, Hashtable *hashtable)
{
    // Used for creating words (appending one character at a time) as we
    // proccess each individual character from the file.
    std::string currentWord;

    // The locale for character manipulation (tolower and isalpha;
    std::locale locale;

    if(hashtable == NULL)
    {
        return false;
    }

    // Attempt to open the file
    std::ifstream file(filename.c_str());
    if(!file.is_open())
    {
        return false;
    }

    // Go throught the file.
    while(file.good())
    {
        // Get the next character out of the file, and convert it to lower case
        char processing = file.get();

	//printf("%c", processing); // to let users know how the loading is doing

        processing = tolower(processing, locale);

        // If it is a valid letter, append it to the currentWord
        if(isalpha(processing, locale))
        {
            currentWord.push_back(processing);
        }
        else if(!currentWord.empty())
        {
            // We now have a new sting that contains only lowercase a-z
            // letters. Add it to the hashtable and clear the word
            bool containsValve = false;
            for(unsigned i=0; i<currentWord.size(); i++)
            {
                char s = currentWord.at(i);

                if(s == 'a' ||
                   s == 'e' ||
                   s == 'i' ||
                   s == 'o' ||
                   s == 'u' ||
                   s == 'y')
                {
                    containsValve = true;
                    break;
                }
            }

            if(!containsValve)
            {
                currentWord.clear();
            }
            else
            {
                hashtable->add(currentWord);
                currentWord.clear();
            }
        }
    }

    // Deals with the possibility that the file ended in an a-z letter, and thus
    // we have one more word that needs to be added to the hash table.
    if(!currentWord.empty())
    {
        hashtable->add(currentWord);
        currentWord.clear();
    }

    file.close();
    return true;
}

void File::parse_string(std::string content, Hashtable *hashtable)
{
    // Used for creating words (appending one character at a time) as we
    // proccess each individual character from the file.
    std::string currentWord;

    // The locale for character manipulation (tolower and isalpha;
    std::locale locale;

    if(hashtable == NULL)
    {
	return;
    }

    // Go throught the file.
    int i=0;
    while(i<content.length())
    {
	// Get the next character out of the file, and convert it to lower case
	char processing = content[i];

	//printf("%c", processing); // to let users know how the loading is doing

	processing = tolower(processing, locale);

	// If it is a valid letter, append it to the currentWord
	if(isalpha(processing, locale))
	{
	    currentWord.push_back(processing);
	}
	else if(!currentWord.empty())
	{
	    // We now have a new sting that contains only lowercase a-z
	    // letters. Add it to the hashtable and clear the word
	    /*bool containsValve = false;
	    for(unsigned i=0; i<currentWord.size(); i++)
	    {
		char s = currentWord.at(i);

		if(s == 'a' ||
		   s == 'e' ||
		   s == 'i' ||
		   s == 'o' ||
		   s == 'u' ||
		   s == 'y')
		{
		    containsValve = true;
		    break;
		}
	    }*/
	    bool containsValve = true;

	    if(!containsValve)
	    {
		currentWord.clear();
	    }
	    else
	    {
		hashtable->add(currentWord);
		currentWord.clear();
	    }
	}
	i++;
    }

    // Deals with the possibility that the file ended in an a-z letter, and thus
    // we have one more word that needs to be added to the hash table.
    if(!currentWord.empty())
    {
	hashtable->add(currentWord);
	currentWord.clear();
    }
}
