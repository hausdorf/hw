#ifndef INCLUDE_libdiff_h__
#define INCLUDE_libdiff_h__

#include "../common.h"



/*
 * Represents file data (binary or text) in memory. Often
 * instances of these structs are the direct objects that
 * diffing is performed on.
 */
struct diff_mem {
	size_t size;
	char *data;
};


/*
 * TODO: DOES THIS NEED TO BE PUBLIC-FACING? POSSIBLY IT DOES.
 * Callback function; usually coordinate the assembly of the diff output.
 */
struct git_diff_callb {
	void *payload;
	int (*func)(void *, struct diff_mem *, int);
};


/*
 * Represents the variables required to run the diffing
 * algorithm. For example, an array longs that hold the hashed
 * value of every line in the data we're diffing, as well as
 * the number of records are kept here.
 */
struct diff_environment {
	// We're diffing data2 against data1; diff generated will be the set
	// of changes required to change data1 into data2
	struct diff_mem diff_me1, diff_me2;
	struct git_diff_callb outpt_bldr;
	//data_context data_ctx1, data_ctx2;
	//record_classifier classifier;
	// Flags points to the flags member of git_diffresults_conf,
	// and is usually set in diff()
	const unsigned long *flags;
};



#endif
