#ifndef XDIFF_INTERFACE_H
#define XDIFF_INTERFACE_H

#include "libdiff.h"
#include "xdiff.h"


typedef void (*xdiff_emit_consume_fn)(void *, char *, unsigned long);
int xdi_diff(struct diff_environment *diff_env, xdemitconf_t const *xecfg, xdemitcb_t *ecb);
int xdi_diff_outf(struct diff_environment *diff_env,
		  xdiff_emit_consume_fn fn, void *consume_callback_data,
		  xdemitconf_t const *xecfg);


#endif
