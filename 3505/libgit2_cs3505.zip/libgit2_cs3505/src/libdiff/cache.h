#ifndef CACHE_H
#define CACHE_H



struct pathspec {
	const char **raw; /* get_pathspec() result, not freed by free_pathspec() */
	int nr;
	unsigned int has_wildcard:1;
	unsigned int recursive:1;
	int max_depth;
	struct pathspec_item {
		const char *match;
		int len;
		unsigned int has_wildcard:1;
	} *items;
};



#endif
