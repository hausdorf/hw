#ifndef STRBUF_H
#define STRBUF_H


char strbuf_slopbuf[];
struct strbuf {
	size_t alloc;
	size_t len;
	char *buf;
};


extern void strbuf_init(struct strbuf *, size_t);
void strbuf_release(struct strbuf *);
int strbuf_grow(struct strbuf *sb, size_t extra);


static inline void strbuf_setlen(struct strbuf *sb, size_t len) {
	if (!sb->alloc)
		strbuf_grow(sb, 0);
	assert(len < sb->alloc);
	sb->len = len;
	sb->buf[len] = '\0';
}
#define strbuf_reset(sb)  strbuf_setlen(sb, 0)


#endif /* STRBUF_H */
