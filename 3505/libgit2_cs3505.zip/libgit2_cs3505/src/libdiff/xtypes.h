/*
 *  LibXDiff by Davide Libenzi ( File Differential Library )
 *  Copyright (C) 2003  Davide Libenzi
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Davide Libenzi <davidel@xmailserver.org>
 *
 */

#if !defined(XTYPES_H)
#define XTYPES_H



typedef struct s_chanode {
	struct s_chanode *next;
	long icurr;
} chanode_t;

typedef struct s_chastore {
	// head and tail initially point to ancur; as we allocate more
	// memory, the tail and head grow apart, but the alloc'd
	// memory is linked by the chanode_t->next links, which usually
	// point to the first address in the chastore allocated blocks
	chanode_t *head, *tail;
	// See xdl_cha_init:
	// - isize is the # of bytes in the sort of struct we're using
	// - nsize is the # of bytes we want to reserve for the store,
	// usually isize * the number of objects we want to store
	long isize, nsize;
	// Handles all the allocation of new memory from the chastore
	chanode_t *ancur;
	// Handles traversal of chastore objects
	chanode_t *sncur;
	// initially 0
	long scurr;
} chastore_t;

typedef struct s_xrecord {
	struct s_xrecord *next;
	char const *ptr;
	long size;
	unsigned long ha;
} xrecord_t;

typedef struct s_xdfile {
	chastore_t rcha;
	// Number of records, which is DEFINITLY
	// lines
	long nrec;
	// Size of rhash???
	unsigned int hbits;
	// A hash table of xrecord pointers; build in
	// xdl_prepare_ctx()
	xrecord_t **rhash;
	// D-path start and end
	long dstart, dend;
	// All records
	xrecord_t **recs;
	// In xdl_recs_cmp, each of these chars is set to a "weight" -- usually
	// 0 or 1 depending on whether that particular record has changed. So
	// it's basically a bit vector made of chars
	char *rchg;
	// An ARRAY of longs that represent hashes; in xdl_recs_cmp(),
	// we access it as an array.
	long *rindex;
	// # of records * size of records???
	long nreff;
	// A hash of the entire xdfile contents
	unsigned long *ha;
} xdfile_t;

typedef struct s_xdfenv {
	xdfile_t xdf1, xdf2;
} xdfenv_t;



#endif /* #if !defined(XTYPES_H) */
