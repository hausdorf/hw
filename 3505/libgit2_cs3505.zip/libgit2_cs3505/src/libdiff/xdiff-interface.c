#include "xdiff-interface.h"
#include "xtypes.h"
#include "xdiffi.h"
#include "xemit.h"
#include "xmacros.h"
#include "strbuf.h"



struct xdiff_emit_state {
	xdiff_emit_consume_fn consume;
	void *consume_callback_data;
	struct strbuf remainder;
};



static void consume_one(void *priv_, char *s, unsigned long size)
{
	struct xdiff_emit_state *priv = priv_;
	char *ep;
	while (size) {
		unsigned long this_size;
		ep = memchr(s, '\n', size);
		this_size = (ep == NULL) ? size : (ep - s + 1);
		priv->consume(priv->consume_callback_data, s, this_size);
		size -= this_size;
		s += this_size;
	}
}


static int xdiff_outf(void *priv_, mmbuffer_t *mb, int nbuf)
{
	struct xdiff_emit_state *priv = priv_;
	int i;

	for (i = 0; i < nbuf; i++) {
		if (mb[i].ptr[mb[i].size-1] != '\n') {
			/* Incomplete line */
			strbuf_add(&priv->remainder, mb[i].ptr, mb[i].size);
			continue;
		}

		/* we have a complete line */
		if (!priv->remainder.len) {
			consume_one(priv, mb[i].ptr, mb[i].size);
			continue;
		}
		strbuf_add(&priv->remainder, mb[i].ptr, mb[i].size);
		consume_one(priv, priv->remainder.buf, priv->remainder.len);
		strbuf_reset(&priv->remainder);
	}
	if (priv->remainder.len) {
		consume_one(priv, priv->remainder.buf, priv->remainder.len);
		strbuf_reset(&priv->remainder);
	}
	return 0;
}


/*
 * Trim down common substring at the end of the buffers,
 * but leave at least ctx lines at the end.
 */
static void trim_common_tail(struct diff_mem *a, struct diff_mem *b, long ctx)
{
	const int blk = 1024;
	long trimmed = 0, recovered = 0;
	char *ap = a->data + a->size;
	char *bp = b->data + b->size;
	long smaller = (a->size < b->size) ? a->size : b->size;

	if (ctx)
		return;

	while (blk + trimmed <= smaller && !memcmp(ap - blk, bp - blk, blk)) {
		trimmed += blk;
		ap -= blk;
		bp -= blk;
	}

	while (recovered < trimmed)
		if (ap[recovered++] == '\n')
			break;
	a->size -= trimmed - recovered;
	b->size -= trimmed - recovered;
}


int xdi_diff_outf(struct diff_environment *diff_env,
		  xdiff_emit_consume_fn fn, void *consume_callback_data,
		  xdemitconf_t const *xecfg)
{
	int ret;
	struct xdiff_emit_state state;
	xdemitcb_t ecb;

	memset(&state, 0, sizeof(state));
	state.consume = fn;
	state.consume_callback_data = consume_callback_data;
	memset(&ecb, 0, sizeof(ecb));
	ecb.outf = xdiff_outf;
	ecb.priv = &state;
	strbuf_init(&state.remainder, 0);
	ret = xdi_diff(diff_env, xecfg, &ecb);
	strbuf_release(&state.remainder);
	return ret;
}


int xdi_diff(struct diff_environment *diff_env, xdemitconf_t const *xecfg, xdemitcb_t *xecb)
{
	trim_common_tail(&diff_env->diff_me1, &diff_env->diff_me2, xecfg->ctxlen);
	xpparam_t xpp;

	return xdl_diff(diff_env, xecfg, xecb);
}

