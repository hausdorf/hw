#ifndef GDIFF_H
#define GDIFF_H


#include "../common.h"
#include "cache.h"
#include "xinclude.h"



struct diff_options;
struct diff_queue_struct;
struct strbuf;



typedef void (*change_fn_t)(struct diff_options *options,
		 unsigned old_mode, unsigned new_mode,
		 const unsigned char *old_sha1,
		 const unsigned char *new_sha1,
		 const char *fullpath,
		 unsigned old_dirty_submodule, unsigned new_dirty_submodule);


typedef void (*add_remove_fn_t)(struct diff_options *options,
		    int addremove, unsigned mode,
		    const unsigned char *sha1,
		    const char *fullpath, unsigned dirty_submodule);


typedef void (*diff_format_fn_t)(struct diff_queue_struct *q,
		struct diff_options *options, void *data);


typedef struct strbuf *(*diff_prefix_fn_t)(struct diff_options *opt, void *data);


enum diff_words_type {
	DIFF_WORDS_NONE = 0,
	DIFF_WORDS_PORCELAIN,
	DIFF_WORDS_PLAIN,
	DIFF_WORDS_COLOR
};


struct diff_options {
	const char *filter;
	const char *orderfile;
	const char *pickaxe;
	const char *single_follow;
	const char *a_prefix, *b_prefix;
	unsigned flags;
	int context;
	int interhunkcontext;
	int break_opt;
	int detect_rename;
	int skip_stat_unmatch;
	int line_termination;
	int output_format;
	int pickaxe_opts;
	int rename_score;
	int rename_limit;
	int needed_rename_limit;
	int show_rename_progress;
	int dirstat_percent;
	int setup;
	int abbrev;
	const char *prefix;
	int prefix_length;
	const char *stat_sep;
	long xdl_opts;

	int stat_width;
	int stat_name_width;
	const char *word_regex;
	enum diff_words_type word_diff;

	/* this is set by diffcore for DIFF_FORMAT_PATCH */
	int found_changes;

	/* to support internal diff recursion by --follow hack*/
	int found_follow;

	FILE *file;
	int close_file;

	struct pathspec pathspec;
	change_fn_t change;
	add_remove_fn_t add_remove;
	diff_format_fn_t format_callback;
	void *format_callback_data;
	diff_prefix_fn_t output_prefix;
	void *output_prefix_data;
};


enum color_diff {
	DIFF_RESET = 0,
	DIFF_PLAIN = 1,
	DIFF_METAINFO = 2,
	DIFF_FRAGINFO = 3,
	DIFF_FILE_OLD = 4,
	DIFF_FILE_NEW = 5,
	DIFF_COMMIT = 6,
	DIFF_WHITESPACE = 7,
	DIFF_FUNCINFO = 8
};
const char *diff_get_color(int diff_use_color, enum color_diff ix);
void diff_interface(struct diff_environment *diff_env,
		  xdemitconf_t const *xecfg, xdemitconf_t *ecb);


#endif /* GDIFF_H */
