#include <stdio.h>
#include <git2.h>

int main() {
	git_diffresults_conf *conf;
	git_repository *repo;
	git_repository_open(&repo, "");
	git_index *index;
	git_commit *commit1;
	git_commit *commit2;

	//git_diff(diffdata, commit1, repo);

	git_diff_no_index(&conf, "difftest_before", "difftest_after");

	//git_diff_cached(diffdata, commit1, index);
	//git_diff_commits(diffdata, commit1, commit2);
}
