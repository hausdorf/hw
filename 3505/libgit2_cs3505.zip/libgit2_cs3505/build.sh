#!/usr/bin/env bash

echo "Configuring..."
/usr/local/bin/python2.5 waf configure
echo "Done"

echo "Building static..."
/usr/local/bin/python2.5 waf build-static 
echo "Done"

echo "Building shared..."
/usr/local/bin/python2.5 waf build-shared 
echo "Done"

echo "Compiling libgit2..."
/usr/local/bin/gcc -Iinclude/ main.c build/static/libgit2.a
echo "Completed"

echo
echo
echo "Thanks for compiling, enjoy"
echo "  Sincerely,"
echo "  Godzillasaurus Rex"
