function mysaveas(fig,fn)
if isMatlab,
  saveas(fig,fn);
end;
